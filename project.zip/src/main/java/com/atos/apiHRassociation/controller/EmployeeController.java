package com.atos.apiHRassociation.controller;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.atos.apiHRassociation.model.Employee;
import com.atos.apiHRassociation.service.EmployeeService;


//Le package "controller" s'occupe de réceptionner la requête et de fournir la réponse 


@RestController
//annoation spécialisée de @Component comme l'annotation @Repository
//ET elle indique à Spring d’insérer le retour de la méthode au format JSON dans le corps de la réponse HTTP.
//Grâce à ce deuxième point, les applications qui vont communiquer avec l'API accéderont au résultat de leur requête en parsant la réponse HTTP.
public class EmployeeController {

	@Autowired
	//en mettant l’annotation @Autowired sur l’attribut EmployeeService,
	//Spring va chercher au sein de son contexte s’il existe un bean de type EmployeeService
	//S’il le trouve, il va alors instancier la classe de ce bean et injecter cette instance dans l’attribut.
	//Si non => error
	//Ici, cela permettra d’appeler les méthodes d'EmployeeService pour communiquer avec la base de données.
	private EmployeeService employeeService;
	
	/**
	 * Create - Add a new employee
	 * @param employee An object employee
	 * @return The employee object saved
	 */
	@PostMapping("/employee")
	public Employee createEmployee(@RequestBody Employee employee) {
		return employeeService.saveEmployee(employee);
	}
	
	
	/**
	 * Read - Get one employee 
	 * @param id The id of the employee
	 * @return An Employee object full filled
	 */
	@GetMapping("/employee/{id}")
	public Employee getEmployee(@PathVariable("id") final Long id) {
		Optional<Employee> employee = employeeService.getEmployee(id);
		if(employee.isPresent()) {
			return employee.get();
		} else {
			return null;
		}
	}
	
	/**
	 * Read - Get all employees
	 * @return - An Iterable object of Employee full filled
	 */
	@GetMapping("/employees")
	public Iterable<Employee> getEmployees() {
		return employeeService.getEmployees();
	}
	
	/**
	 * Update - Update an existing employee
	 * @param id - The id of the employee to update
	 * @param employee - The employee object updated
	 * @return
	 */
	@PutMapping("/employee/{id}")
	public Employee updateEmployee(@PathVariable("id") final Long id, @RequestBody Employee employee) {
		Optional<Employee> e = employeeService.getEmployee(id);
		if(e.isPresent()) {
			Employee currentEmployee = e.get();
			
			String firstName = employee.getFirstName();
			if(firstName != null) {
				currentEmployee.setFirstName(firstName);
			}
			String lastName = employee.getLastName();
			if(lastName != null) {
				currentEmployee.setLastName(lastName);
			}
			String mail = employee.getMail();
			if(mail != null) {
				currentEmployee.setMail(mail);
			}
			String password = employee.getPassword();
			if(password != null) {
				currentEmployee.setPassword(password);;
			}
			employeeService.saveEmployee(currentEmployee);
			return currentEmployee;
		} else {
			return null;
		}
	}
	
	
	/**
	 * Delete - Delete an employee
	 * @param id - The id of the employee to delete
	 */
	@DeleteMapping("/employee/{id}")
	public void deleteEmployee(@PathVariable("id") final Long id) {
		employeeService.deleteEmployee(id);
	}
		
		
}
    
    
    



/** POUR INFORMATION : 
* @GetMapping => GET => Pour la lecture de données.
*
* @PostMapping => POST => Pour l’envoi de données. Cela sera utilisé par exemple pour créer un nouvel élément.
*
* @PatchMapping => PATCH => Pour la mise à jour partielle de l’élément envoyé.
*
* @PutMapping => PUT => Pour le remplacement complet de l’élément envoyé.
*
* @DeleteMapping => DELETE => Pour la suppression de l’élément envoyé.
*
* @RequestMapping => Intègre tous les types HTTP. Le type souhaité est indiqué comme attribut de l’annotation.
* Exemple : @RequestMapping(method = RequestMethod.GET)
* */
