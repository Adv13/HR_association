package com.atos.apiHRassociation.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atos.apiHRassociation.model.Employee;
import com.atos.apiHRassociation.repository.EmployeeRepository;

import lombok.Data;

//Le package "service" exécute les traitement métiers


@Data
//est une annotation Lombok. Nul besoin d’ajouter les getters et les setters.
@Service
// annoation spécialisée de @Component comme l'annotation @Repository
public class EmployeeService {

	@Autowired
	//en mettant l’annotation @Autowired sur l’attribut EmployeeRepository,
	//Spring va chercher au sein de son contexte s’il existe un bean de type EmployeeRepository
	//S’il le trouve, il va alors instancier la classe de ce bean et injecter cette instance dans l’attribut.
	//Si non => error
	private EmployeeRepository employeeRepository;
	
	//retourne un employee par son id
	public Optional<Employee> getEmployee(final Long id){
		return employeeRepository.findById(id);
	}
	
	//retourne tous les employees dans la database
	public Iterable<Employee> getEmployees(){
		return employeeRepository.findAll();
	}
	
	//supprime un employee dans la database par son id
	public void deleteEmployee(final Long id) {
		employeeRepository.deleteById(id);
	}
	
	//sauvegarde/ajoute un employee dans la database 
	public Employee saveEmployee(Employee employee) {
		Employee savedEmployee = employeeRepository.save(employee);
		return savedEmployee;
	}
}
