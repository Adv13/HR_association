package com.atos.apiHRassociation.model;
// Le package "model" contient les objets métiers


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
//est une annotation Lombok. Nul besoin d’ajouter les getters et les setters. La librairie Lombok s’en charge pour nous. Très utile pour alléger le code.
@Entity
//est une annotation qui indique que la classe correspond à une table de la base de données.
@Table(name="employees")
//indique le nom de la table associée.
@Getter 
@Setter
public class Employee {
	@Id
	//L’attribut id correspond à la clé primaire de la table.
	//Comme l’id est auto-incrémenté, on met l'annotation suivante :
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="first_name")
	//pour faire le lien avec le nom du champ de la table
	private String firstName;
	
	@Column(name="last_name")
	//pour faire le lien avec le nom du champ de la table
	private String lastName;
	
	//Pas besoin de mettre cette annotation pour mail et password, car le nom du champ de la table est identique.
	private String mail;
	
	private String password;
}
