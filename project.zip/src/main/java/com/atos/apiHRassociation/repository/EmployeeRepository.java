package com.atos.apiHRassociation.repository;
//Le package "repository" contient la manière de communiquer avec la source de données

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.atos.apiHRassociation.model.Employee;

@Repository
//est une annotation Spring pour indiquer que la classe est un bean, et que son rôle est de communiquer avec une source de données (en l'occurrence la base de données).
//@Repository est une spécialisation de @Component. Tout comme @Component, elle permet de déclarer auprès de Spring qu’une classe est un bean à exploiter.
//Par son nom, on fournit au développeur une indication sémantique sur le rôle de la classe mais @Component marche très bien ici aussi. 
public interface EmployeeRepository extends CrudRepository<Employee, Long> {
	//CrudRepository est une interface fournie par Spring.
	//Elle fournit des méthodes pour manipuler votre entité par la généricité (cf Typescript)
	//ATTENTION : La classe entité fournie doit être annotée @Entity, sinon Spring retournera une erreur.

	
	
}
