package com.atos.apiHRassociation.controllerTests;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.atos.apiHRassociation.controller.EmployeeController;
import com.atos.apiHRassociation.service.EmployeeService;

@SpringBootTest
//@WebMvcTest(controllers = EmployeeController.class)
//déclenche le mécanisme permettant de tester les controllers. On indique également le ou les controllers concernés.


@AutoConfigureMockMvc
public class EmployeeControllerTest {

    @Autowired
    private MockMvc mockMvc;
    //L’attribut mockMvc est un élément important. Il permet d’appeler la méthode “perform” qui déclenche la requête.

    @MockBean
    private EmployeeService employeeService;
    //L’attribut employeeService est annoté @MockBean.
    //Il est obligatoire, car la méthode du controller exécutée par l’appel de “/employees” utilise cette classe.

    @Test
    //Test unitaire
    public void testGetEmployeesU() throws Exception {
        mockMvc.perform(get("/employees"))//On exécute donc une requête GET sur l’URL /employees.
            .andExpect(status().isOk());//nous attendons une réponse HTTP 200. 
    }
    
    @Test
    //Test d'intégration
    public void testGetEmployeesI() throws Exception {
        mockMvc.perform(get("/employees"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].firstName", is("Laurent")));
    }
	
}
